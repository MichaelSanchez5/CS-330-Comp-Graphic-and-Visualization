﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
///////////////////////////////////////////////////////////////////////////////
// maincode.cpp
// ============
// gets called when application is launched - initializes GLEW, GLFW
//
//  AUTHOR: Tarik Iles - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Oct. 18th, 2025
///////////////////////////////////////////////////////////////////////////////

#include <iostream>         // error handling and output
#include <cstdlib>          // EXIT_FAILURE

#include <GL/glew.h>        // GLEW library
#include "GLFW/glfw3.h"     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Namespace for declaring global variables
namespace
{
    // Macro for window title
    const char* const WINDOW_TITLE = " Michael_Sanchez_7-1 FinalProject and Milestones";

    // Main GLFW window
    GLFWwindow* g_Window = nullptr;

    // scene manager object for managing the 3D scene prepare and render
    SceneManager* g_SceneManager = nullptr;
    // shader manager object for dynamic interaction with the shader code
    ShaderManager* g_ShaderManager = nullptr;
    // view manager object for managing the 3D view setup and projection to 2D
    ViewManager* g_ViewManager = nullptr;
}

// Function declarations - all functions that are called manually
// need to be pre-declared at the beginning of the source code.
bool InitializeGLFW();
bool InitializeGLEW();


/***********************************************************
 *  main(int, char*)
 *
 *  This function gets called after the application has been
 *  launched.
 ***********************************************************/
int main(int argc, char* argv[])
{
    // if GLFW fails initialization, then terminate the application
    if (InitializeGLFW() == false)
    {
        return (EXIT_FAILURE);
    }

    // try to create a new shader manager object
    g_ShaderManager = new ShaderManager();
    // try to create a new view manager object
    g_ViewManager = new ViewManager(
        g_ShaderManager);

    // try to create the main display window
    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);

    // if GLEW fails initialization, then terminate the application
    if (InitializeGLEW() == false)
    {
        return (EXIT_FAILURE);
    }

    // load the shader code from the external GLSL files
    g_ShaderManager->LoadShaders(
        "shaders/vertexShader.glsl",
        "shaders/fragmentShader.glsl");
    g_ShaderManager->use();

    // try to create a new scene manager object and prepare the 3D scene
    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    // loop will keep running until the application is closed 
    // or until an error has occurred
    while (!glfwWindowShouldClose(g_Window))
    {
        // Enable z-depth
        glEnable(GL_DEPTH_TEST);

        // Clear the frame and z buffers
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // convert from 3D object space to 2D view
        g_ViewManager->PrepareSceneView();

        // refresh the 3D scene
        g_SceneManager->RenderScene();


        // Flips the the back buffer with the front buffer every frame.
        glfwSwapBuffers(g_Window);

        // query the latest GLFW events
        glfwPollEvents();
    }

    // clear the allocated manager objects from memory
    if (NULL != g_SceneManager)
    {
        delete g_SceneManager;
        g_SceneManager = NULL;
    }
    if (NULL != g_ViewManager)
    {
        delete g_ViewManager;
        g_ViewManager = NULL;
    }
    if (NULL != g_ShaderManager)
    {
        delete g_ShaderManager;
        g_ShaderManager = NULL;
    }

    // Terminates the program successfully
    exit(EXIT_SUCCESS);
}

/***********************************************************
 *	InitializeGLFW()
 * 
 *  This function is used to initialize the GLFW library.   
 ***********************************************************/
bool InitializeGLFW()
{
    // GLFW: initialize and configure library
    // --------------------------------------
    glfwInit();

# ifdef __APPLE__
    // set the version of OpenGL and profile to use
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    // set the version of OpenGL and profile to use
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif
    // GLFW: end -------------------------------

    return (true);
}

/***********************************************************
 *	InitializeGLEW()
 *
 *  This function is used to initialize the GLEW library.
 ***********************************************************/
bool InitializeGLEW()
{
    // GLEW: initialize
    // -----------------------------------------
    GLenum GLEWInitResult = GLEW_OK;

    // try to initialize the GLEW library
    GLEWInitResult = glewInit();
    if (GLEW_OK != GLEWInitResult)
    {
        std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
        return false;
    }
    // GLEW: end -------------------------------

    // Displays a successful OpenGL initialization message
    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n" << std::endl;

    return (true);
}

///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager * pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
int height = 0;
int colorChannels = 0;
GLuint textureID = 0;

// indicate to always flip images vertically when loaded
stbi_set_flip_vertically_on_load(true);

// try to parse the image data from the specified image file
unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

// if the image was successfully read from the image file
if (image)
{
    std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // if the loaded image is in RGB format
    if (colorChannels == 3)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    // if the loaded image is in RGBA format - it supports transparency
    else if (colorChannels == 4)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    else
    {
        std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
        return false;
    }

    // generate the texture mipmaps for mapping textures to lower resolutions
    glGenerateMipmap(GL_TEXTURE_2D);

    // free the image data from local memory
    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

    // register the loaded texture and associate it with the special tag string
    m_textureIDs[m_loadedTextures].ID = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    return true;
}

std::cout << "Could not load image:" << filename << std::endl;

// Error loading the image
return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glGenTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return (textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return (textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL & material)
{
    if (m_objectMaterials.size() == 0)
    {
        return (false);
    }

    int index = 0;
    bool bFound = false;
    while ((index < m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return (true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    // variables for this method
    glm::mat4 modelView;
    glm::mat4 scale;
    glm::mat4 rotationX;
    glm::mat4 rotationY;
    glm::mat4 rotationZ;
    glm::mat4 translation;

    // set the scale value in the transform buffer
    scale = glm::scale(scaleXYZ);
    // set the rotation values in the transform buffer
    rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    // set the translation value in the transform buffer
    translation = glm::translate(positionXYZ);

    modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    // variables for this method
    glm::vec4 currentColor;

    currentColor.r = redColorValue;
    currentColor.g = greenColorValue;
    currentColor.b = blueColorValue;
    currentColor.a = alphaValue;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
    std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureID = -1;
        textureID = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
    std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = false;

        bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // only one instance of a particular mesh needs to be
    // loaded in memory no matter how many times it is drawn
    // in the rendered 3D scene

    m_basicMeshes->LoadPlaneMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
    // declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    /*** Set needed transformations before drawing the basic mesh.  ***/
    /*** This same ordering of code should be used for transforming ***/
    /*** and drawing all the basic 3D shapes.						***/
    /******************************************************************/
    // set the XYZ scale for the mesh
    scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

    // set the XYZ rotation for the mesh
    XrotationDegrees = 0.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;

    // set the XYZ position for the mesh
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

    // set the transformations into memory to be used on the drawn meshes
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    SetShaderColor(1, 1, 1, 1);

    // draw the mesh with transformation values
    m_basicMeshes->DrawPlaneMesh();
    m_basicMeshes->DrawPyramidMesh();
    m_basicMeshes->DrawSphereMesh();
    m_basicMeshes->DrawBoxMesh();
    m_basicMeshes->DrawConeMesh();
    m_basicMeshes->DrawRectangle();
    m_basicMeshes->DrawcylinderMesh();
    m_basicMeshes->DrawPloygonMesh();
    M - basicMeshes->DrawTriangleMesh();
    /****************************************************************/
}

/****************************************************************/
// Header inclusions
#include <istream>         // For consol output
#include <GL/glew.h>      // GLEW library
#include <GLFW/glfw3.h>  // GLFW library

//GLM Math libraies
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// shader program macro
#ifndef GLSL
#define GLSL (Version, source) "version" #Version "core \n" #Source
#endif 

// Window dimensions
const GLuint WIDTH = 800, HEIGHT = 600;

//vertirx and fragment shader source code
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 postion;
layout(location = 1) in vec4 color;
out vec4 vertexColor;
uniform mat4; model;
uniform mat4; view;
uniform mat4; porjection;
void main()
{
    gl_Postion = projection * view * model * vec4(postion, 1.0f);
    vertexColor = color;
}
);

const GLchar* fragmentShaderSource = GLSL(400,
    in vec4 vertexColor;
out vec4 fragmentColor;
void main()
{
    fragmentColor = vertexColor;
}
);

//Main function portotypes
void URresizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreatePyramid(GLfloat verts[], GLushort indices[]);
void UCreateShaderProgram(const char* vtxShader, const char* fragShaderSource, GLuint& porgramId);

//Main fuction
int main(int argc, char* argv[])
{
    // Initialize GLFW, GLEW, and create window
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindoeHint(GLFW_OPENGL_PORFILE, GLFW_OPENGL_CORE_PROFILE)

        // create window
        GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "3D pyramid", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW winodw" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, UResizeWindow);

    // Initialize GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK)
    {
        std::cout << "Failed to initialize GLEW" << std::endl;
        return -1;
    }

    // Create shader program
    Gluint shaderProgram;
    UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, shaderProgram);

    // Define pyramid vertices and indices
    // A pyramid has 5 vertices (4 for base, 1 for top) and 6 triangualar faces (4 sides + 2 for the base)
    GLfloat vertices[]{
        // postions               // colors(RGBA)
        -0.5f, -0.5f, -0.5f,       1.0f, 0.0f, 0.0f, 1.0f, // vertex 0: Base Bottom-left (red)
		0.5f, -0.5f, -0.5f,        0.0f, 1.0f, 0.0f, 1.0f, // vertex 1: Base Bottom-right (green)
		0.5f, -0.5f, 0.5f,         0.0f, 0.0f, 1.0f, 1.0f, // vertex 2: Base top-right (blue)
		-0.5f, -0.5f, 0.5f,        1.0f, 1.0f, 0.0f, 1.0f, // vertex 3: Base top-left (yellow)
		0.0f, 0.5f, 0.0f,          1.0f, 0.0f, 1.0f, 1.0f, // vertex 4: Pyramid top (purple)
	}
    ;

    // Define indices for the pyramid
    GLushort indices[] = {
        0, 1, 2,    // Base trianlge 1
		0, 2, 3,    // Base trainlge 2
		0, 1, 4     // Side 1

        1, 2, 4     // Side 2 

        2, 3, 4     // Side 3

        3, 0, 4     // Side 4
	};

    // Generate and set up vertex array object (VAO), vertex buffer object (VBO), and element buffer object (EBO)
    GLuint VAO, VBO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffer(1, &VBO);
    glGENBuffers(1, &EBO);

    // Bind VAO first
    glBindVertexArray(VAO);

    // Bind and set VBO
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Bind and set EBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(vertices), vertices, indices, GL_STATIC_DRAW);

    // Set vertex attribute pointers
    // Postion attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // color attribute 
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // Unbind VAO to prevent accidental modifications 
    glBindVertexArray(0);

    // Enbale depth testing
    glEnable(GL_DEPTH_TEST);

    //Render loop
    while (!glfwWindowShouldClose(window))
    {
        // Input processing
        UProcessInput(window);

        // Clear the frame and depth buffers
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(Gl_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // USe the shader program
        glUseProgram(shaderProgram);

        // Create transformations for Model-View-Projection
        // Model martix: rotate the pyramid slowlky around the y-axis 
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::trnslate(view, glm::vec3(0.0f, 0.0f, -3.0f));
        // porjection martix: create prespective projection
        glm::mat4 porjection = glm::prespective(glm::radians(45.0f), (float)WIDTH / (float)HEIGHT, 0.1f, 100.0f);

        // Get the uniform locations and sethe matrices 
        GLint modelLoc = glGetUniformLocation(shaderPorgram, "model");
        GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
        GLint porjLoc = glGetUniformLocation(shaderProgram, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, :value_ptr(model));
glUniformMatirx4fv(viewLoc, 1, GL_FALSE, value_ptr(view));
glProgramUniformMatrix4x3fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

// Draw the pyramid
glBindVertexArray(VAO);
glDrawElements(GL_TRIANGLES, 18, GL_UNSIGNED_SHORT, 0);
glBindVertexArray(0);

// Swap biffers and poll envents
glfwSwapBuffers(window);
glfwPollEvents();
	}
	// Clean up resources
	glDeleteVertexArrays(1, &VAO);
glDeleteBuffers(1, &VBO);
glDeleteBuffers(1, &EBO);
glDeleteProgram(shaderProgram);

// Terminate GLFW
gflwTerminate();
return 0;
}

// Function to handle window resize events
void UResizeWindow(GLFWwindow* winodw, int width, int hieght)
{
    glViewport(0, 0, width, height);
}

// Function to process keyboard input
void UProcessInput(GLFWwindow* window)
{
    // Close window if Escape key is pressed
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwWindowShouldClose(window, true);
}

// Function to create and compile shader porgram
void UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Create vertex shader
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glCompileShader(vertexShaderId);
}

// Check for vertex shader compilation errors
GLint sucess;
GLchar infoLog[512];
glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &sucess);
if (!sucess)
{
    glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
    std::cout << "ERROR::SHADER::VERTEX::COMPIlATION_FAILED\n" << infoLog << std::endl;
}

// Create shader program and link shaders
porgramId = glCreateProgram();
glAttachShader(programId, vertexShaderId);
glAttachShader(programId, fragmentShaderId);
glLinkProgram(programId);

//Check for link errors
glGetProgramiv(programID, GL_LINK_STATUS, &sucess);
if (!success)
{
    glGetProgramInfoLog(programId, 512, NULL, infoLog);
    std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << std::endl
}

// Delete the shader as they're linked into the program and are longer needed
glDeleteShader(vertexShaderId);
glDeleteShader(fragmentShaderId);
}

/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
scaleXYZ = glm::vec3(1.0f, 9.0f, 1.3f);

// set the XYZ rotation for the mesh
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 95.0f;

// set the XYZ position for the mesh
positionXYZ = glm::vec3(0.2f, 2.27f, 2.0f);

// set the transformations into memory to be used on the drawn meshes
SetTransformations(
    scaleXYZ,
    XrotationDegrees,
    YrotationDegrees,
    ZrotationDegrees,
    positionXYZ);

// set the color for the next draw command
SetShaderColor(0, 0, 1, 1);
// draw the filled box shape
m_basicMeshes->DrawBoxMesh();
/****************************************************************/

/*** Set needed transformations before drawing the basic mesh.  ***/
/*** This same ordering of code should be used for transforming ***/
/*** and drawing all the basic 3D shapes.						***/
/******************************************************************/
// set the XYZ scale for the mesh
scaleXYZ = glm::vec3(1.7f, 1.5f, 1.5f);

// set the XYZ rotation for the mesh
XrotationDegrees = 0.0f;
YrotationDegrees = 40.0f;
ZrotationDegrees = 8.0f;

// set the XYZ position for the mesh
positionXYZ = glm::vec3(3.3f, 3.85f, 2.19f);

// set the transformations into memory to be used on the drawn meshes
SetTransformations(
    scaleXYZ,
    XrotationDegrees,
    YrotationDegrees,
    ZrotationDegrees,
    positionXYZ);

// set the color for the next draw command
SetShaderColor(1, 0, 1, 1);
// draw the filled box shape
m_basicMeshes->DrawBoxMesh();
/****************************************************************/

/*** Set needed transformations before drawing the basic mesh.  ***/
/*** This same ordering of code should be used for transforming ***/
/*** and drawing all the basic 3D shapes.						***/
/******************************************************************/
// set the XYZ scale for the mesh
scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);

// set the XYZ rotation for the mesh
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 0.0f;

// set the XYZ position for the mesh
positionXYZ = glm::vec3(3.1f, 5.6f, 2.5f);

// set the transformations into memory to be used on the drawn meshes
SetTransformations(
    scaleXYZ,
    XrotationDegrees,
    YrotationDegrees,
    ZrotationDegrees,
    positionXYZ);
//Main function portotypes
void URresizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreatePyramid(GLfloat verts[], GLushort indices[]);
void UCreateShaderProgram(const char* vtxShader, const char* fragShaderSource, GLuint& porgramId);

//Main fuction
int main(int argc, char* argv[])
{
    // Initialize GLFW, GLEW, and create window
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindoeHint(GLFW_OPENGL_PORFILE, GLFW_OPENGL_CORE_PROFILE)

        // create window
        GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "3D Box", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW winodw" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, UResizeWindow);

    // Initialize GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK)
    {
        std::cout << "Failed to initialize GLEW" << std::endl;
        return -1;
    }

    // Create shader program
    Gluint shaderProgram;
    UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, shaderProgram);

    // Define pyramid vertices and indices
    // A box has 4 vertices (3 for base, 1 for top) and 4 rectangualar faces (4 sides + 1 for the base)
    GLfloat vertices[]{
        // postions               // colors(RGBA)
        -0.5f, -0.5f, -0.5f,       1.0f, 0.0f, 0.0f, 1.0f, // vertex 0: Base Bottom-left (red)
		0.5f, -0.5f, -0.5f,        0.0f, 1.0f, 0.0f, 1.0f, // vertex 1: Base Bottom-right (green)
		0.5f, -0.5f, 0.5f,         0.0f, 0.0f, 1.0f, 1.0f, // vertex 2: Base top-right (blue)
		-0.5f, -0.5f, 0.5f,        1.0f, 1.0f, 0.0f, 1.0f, // vertex 3: Base top-left (yellow)
		0.0f, 0.5f, 0.0f,          1.0f, 0.0f, 1.0f, 1.0f, // vertex 4: Box top (purple)
	}
    ;

    // Define indices for the box
    GLushort indices[] = {
        0, 1, 2,    // Base side 1
		0, 2, 5,    // Base side 2
		0, 1, 4     // Side 1

        1, 2, 4     // Side 2 

        2, 2, 4     // Side 3

        2, 0, 4     // Side 4
	};

    // Generate and set up vertex array object (VAO), vertex buffer object (VBO), and element buffer object (EBO)
    GLuint VAO, VBO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffer(1, &VBO);
    glGENBuffers(1, &EBO);

    // Bind VAO first
    glBindVertexArray(VAO);

    // Bind and set VBO
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Bind and set EBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(vertices), vertices, indices, GL_STATIC_DRAW);

    // Set vertex attribute pointers
    // Postion attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // color attribute 
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // Unbind VAO to prevent accidental modifications 
    glBindVertexArray(0);

    // Enbale depth testing
    glEnable(GL_DEPTH_TEST);

    //Render loop
    while (!glfwWindowShouldClose(window))
    {
        // Input processing
        UProcessInput(window);

        // Clear the frame and depth buffers
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(Gl_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // USe the shader program
        glUseProgram(shaderProgram);

        // Create transformations for Model-View-Projection
        // Model martix: rotate the pyramid slowlky around the y-axis 
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::trnslate(view, glm::vec3(0.0f, 0.0f, -3.0f));
        // porjection martix: create prespective projection
        glm::mat4 porjection = glm::prespective(glm::radians(45.0f), (float)WIDTH / (float)HEIGHT, 0.1f, 100.0f);

        // Get the uniform locations and sethe matrices 
        GLint modelLoc = glGetUniformLocation(shaderPorgram, "model");
        GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
        GLint porjLoc = glGetUniformLocation(shaderProgram, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, :value_ptr(model));
glUniformMatirx4fv(viewLoc, 1, GL_FALSE, value_ptr(view));
glProgramUniformMatrix4x3fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

// Draw the box
glBindVertexArray(VAO);
glDrawElements(GL_boxsides, 18, GL_UNSIGNED_SHORT, 0);
glBindVertexArray(0);

// Swap biffers and poll envents
glfwSwapBuffers(window);
glfwPollEvents();
	}
	// Clean up resources
	glDeleteVertexArrays(1, &VAO);
glDeleteBuffers(1, &VBO);
glDeleteBuffers(1, &EBO);
glDeleteProgram(shaderProgram);

// Terminate GLFW
gflwTerminate();
return 0;
}

// Function to handle window resize events
void UResizeWindow(GLFWwindow* winodw, int width, int hieght)
{
    glViewport(0, 0, width, height);
}

// Function to process keyboard input
void UProcessInput(GLFWwindow* window)
{
    // Close window if Escape key is pressed
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwWindowShouldClose(window, true);
}

// Function to create and compile shader porgram
void UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Create vertex shader
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glCompileShader(vertexShaderId);
}

// Check for vertex shader compilation errors
GLint sucess;
GLchar infoLog[512];
glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &sucess);
if (!sucess)
{
    glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
    std::cout << "ERROR::SHADER::VERTEX::COMPIlATION_FAILED\n" << infoLog << std::endl;
}

// Create shader program and link shaders
porgramId = glCreateProgram();
glAttachShader(programId, vertexShaderId);
glAttachShader(programId, fragmentShaderId);
glLinkProgram(programId);

//Check for link errors
glGetProgramiv(programID, GL_LINK_STATUS, &sucess);
if (!success)
{
    glGetProgramInfoLog(programId, 512, NULL, infoLog);
    std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << std::endl
}

// Delete the shader as they're linked into the program and are longer needed
glDeleteShader(vertexShaderId);
glDeleteShader(fragmentShaderId);
}
// set the color for the next draw command
SetShaderColor(1, 1, 0, 1);
// draw the filled sphere shape
m_basicMeshes->DrawSphereMesh();
/****************************************************************/

/*** Set needed transformations before drawing the basic mesh.  ***/
/*** This same ordering of code should be used for transforming ***/
/*** and drawing all the basic 3D shapes.						***/
/******************************************************************/
// set the XYZ scale for the mesh
scaleXYZ = glm::vec3(1.2f, 4.0f, 1.2f);

// set the XYZ rotation for the mesh
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 5.0f;

// set the XYZ position for the mesh
positionXYZ = glm::vec3(-3.3f, 2.50f, 2.0f);

// set the transformations into memory to be used on the drawn meshes
SetTransformations(
    scaleXYZ,
    XrotationDegrees,
    YrotationDegrees,
    ZrotationDegrees,
    positionXYZ);

// set the color for the next draw command
SetShaderColor(0, 1, 0, 1);
// draw the filled cone shape
m_basicMeshes->DrawConeMesh();
/****************************************************************/
}
/****************************************************************/

/*** Set needed transformations before drawing the basic mesh.  ***/
/*** This same ordering of code should be used for transforming ***/
/*** and drawing all the basic 3D shapes.						***/
/******************************************************************/
// set the XYZ scale for the mesh
scaleXYZ = glm::vec3(1.4f, 4.0f, 1.3f);

// set the XYZ rotation for the mesh
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 5.0f;

// set the XYZ position for the mesh
positionXYZ = glm::vec3(-1.3f, 2.25f, 2.0f);

// set the transformations into memory to be used on the drawn meshes
SetTransformations(
    scaleXYZ,
    XrotationDegrees,
    YrotationDegrees,
    ZrotationDegrees,
    positionXYZ);
  }

}

/*********************************************************** 
*  LoadSceneTextures() 
* 
*  This method is used for preparing the 3D scene by loading 
*  the shapes, textures in memory to support the 3D scene 
*  rendering 
***********************************************************/ 
void SceneManager::LoadSceneTextures()
{
    bool bReturn = false;

    bReturn = CreateGLTexture(
      "../../Utlities/textures/smooth-raked-sand.jpg",
      "floor");

    bReturn = CreateGLTexture(
     "../../Utlities/textures/rock-texture.jpg",
     "pyramid");

    bReturn = CreateGLTexture(
     "../../Utlities/textures/clay-finish-texture.jpg",
     "sphere");

    bReturn = CreateGLTexture(
     "../../Utlities/textures/rustcwood.jpg",
     "plank");

    bReturn = CreateGLTexture(
     "../../Utlities/textures/rustwood-texture.jpg",
     "box");

    bReturn = CreateGLTexture(
     "../../Utlities/textures/redwood.jpg",
     "rectangle");

    bReturn = CreateGLTexture(
     "../../Utlities/textures/rustwood-texture.jpg",
     "cone");

    bReturn = CreateGLTexture(
    "../../Utilities/textures/redwood.jpg",
    "cylinder");

    bReturn = CreateGLTexture(
     "../../Utilities/textures/Brushwood.jpg",
     "Polygon");

    bReturn = CreateGLTexture(
    "../../Utilities/textures/Brushwood.jpg",
    "triangle");

    // after the texture image data is loaded into memory, the 
    // loaded textures need to be bound to texture slots - there 
    // are a total of 18 available slots for scene textures 
    BindGLTextures();

    /*********************************************************** 
    *  PrepareScene() 
    * 
    *  This method is used for preparing the 3D scene by loading 
    *  the shapes, textures in memory to support the 3D scene  
    *  rendering 
    ***********************************************************/
    void SceneManager::PrepareScene()

{
    }
    LoadSceneTextures();
    // only one instance of a particular mesh needs to be 
    // loaded in memory no mater how many times it is drawn 
    // in the rendered 3D scene 
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadPyramid();
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadRetangleMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadPolygonMesh();
    m_basicMeshes->LoadTriangleMesh();
    Once the textures have been loaded and bound to OpenGL, you can then use them while drawing the
    basic 3D shapes.Look at the starting code in the RenderScene() method for an example: 
/*********************************************************** 
*  RenderScene() 
* 
*  This method is used for rendering the 3D scene by  
*  transforming and drawing the basic 3D shapes 
***********************************************************/ 
void SceneManager::RenderScene()
    {
        // declare the variables for the transformations 
        glm::vec3 scaleXYZ;
        float XrotationDegrees = 0.0f;
        float YrotationDegrees = 0.0f;
        float ZrotationDegrees = 0.0f;
        glm::vec3 positionXYZ;
        glm::mat4 scale;
        glm::mat4 rotation;
        glm::mat4 rotation2;
        glm::mat4 translation;
        glm::mat4 model;
        /*** Set needed transformations before drawing the basic mesh ***/
        // set the XYZ scale for the mesh 
        scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
        // set the XYZ rotation for the mesh 
        Xrota�onDegrees = 0.0f;
        Yrota�onDegrees = 0.0f;
        Zrota�onDegrees = 0.0f;
        // set the XYZ position for the mesh 
        positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

        // set the transformations into memory to be used on the drawn meshes 
        SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);
        //SetShaderColor(1, 1, 1, 1); 
        SetShaderTexture("floor");
        // draw the mesh with transformation values - this plane is used for the base 
        m_basicMeshes->DrawPlaneMesh();

        /////////////////////////////////////////////////// 
        // 
        LoadPlaneMesh()
    // 
    // 
    //   
    //   
    //  
    //   
    // 
    // 
Create a plane mesh by specifying the vertices and
store it in a VAO/ VBO.The normals and texture
coordinates are also set.
Correct triangle drawing command: 
glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);
        /////////////////////////////////////////////////// 
        void ShapeMeshes::LoadPlaneMesh()
    {
            // Vertex data
        }
        GLfloat verts[] = { 
  // Vertex Positions // Normals  // Texture coords  // Index 
  -1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,  0.0f, 0.0f,  //0 
  1.0f, 0.0f, 1.0f,  0.0f, 1.0f, 0.0f,  1.0f, 0.0f,  //1 
  1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,  1.0f, 1.0f,  //2 
  -1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,  0.0f, 1.0f,  //3 
 };

        /*********************************************************** 
        *  CreateGLTexture() 
        * 
        *  This method is used for loading textures from image files, 
        *  configuring the texture mapping parameters in OpenGL,  
        *  genera�ng the mipmaps, and loading the read texture into 
        *  the next available texture slot in memory. 
        ***********************************************************/
        bool SceneManager::CreateGLTexture(const char* filename, std::string tag) 
{
        int width = 0;
        int height = 0;
        int colorChannels = 0;
        GLuint textureID = 0;

        // indicate to always flip images ver�cally when loaded 
        stbi_set_flip_ver�cally_on_load(true);

        // try to parse the image data from the specified image file 
        unsigned char* image = stbi_load(
         filename,
         &width,
         &height,
         &colorChannels,
         0);

        // if the image was successfully read from the image file 
        if (image)
        {
            std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", 
       height: " << height << ", channels: " << colorChannels << std::endl; 
       

  glGenTextures(1, &textureID);
            glBindTexture(GL_TEXTURE_2D, textureID);
            // set the texture wrapping parameters 
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            // set texture filtering parameters 
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

            // if the loaded image is in RGB format 
            if (colorChannels == 3)
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB,
                GL_UNSIGNED_BYTE, image);
            // if the loaded image is in RGBA format - it supports transparency 
            else if (colorChannels == 4)
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA,
                GL_UNSIGNED_BYTE, image);
            else
            {
                std::cout << "Not implemented to handle image with " << colorChannels << " 
          channels" << std::endl; 
             return false;
            }

            // generate the texture mipmaps for mapping textures to lower resolu�ons 
            glGenerateMipmap(GL_TEXTURE_2D);

            // free the image data from local memory 
            stbi_image_free(image);
            glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture 

            // register the loaded texture and associate it with the special tag string 
            m_textureIDs[m_loadedTextures].ID = textureID;
            m_textureIDs[m_loadedTextures].tag = tag;
            m_loadedTextures++;

            return true;
        }

        std::cout << "Could not load image:" << filename << std::endl;

        // Error loading the image 
        return false;
    }

< script src = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js" ></ script >
const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    camera.position.z = 10;

    // Material for the gate
    const material = new THREE.MeshBasicMaterial({ color: 0xff0000 });

// Vertical pillars
const pillar1 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 5, 0.5), material);
pillar1.position.set(-2, 0, 0);
scene.add(pillar1);

const pillar2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 5, 0.5), material);
pillar2.position.set(2, 0, 0);
scene.add(pillar2);

// Top horizontal beam (lintel)
const topBeam = new THREE.Mesh(new THREE.BoxGeometry(6, 0.5, 0.5), material);
topBeam.position.set(0, 2.5, 0);
scene.add(topBeam);

// Secondary horizontal beam
const secondaryBeam = new THREE.Mesh(new THREE.BoxGeometry(4, 0.3, 0.5), material);
secondaryBeam.position.set(0, 1.8, 0);
scene.add(secondaryBeam);

const light = new THREE.PointLight(0xffffff, 1, 100);
light.position.set(10, 10, 10);
scene.add(light);

function animate()
{
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}
animate();